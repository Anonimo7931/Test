package co.com.choucair.certification.camilogomez.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.utest.com")
public class UTestPage extends PageObject {
}
